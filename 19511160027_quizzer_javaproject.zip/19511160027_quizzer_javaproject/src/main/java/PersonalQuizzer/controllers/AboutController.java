package PersonalQuizzer.controllers;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class AboutController implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }


public String url;
    @FXML
    void goFacebook() {
        try {

            new ProcessBuilder("https://www.facebook.com/ivy.okorie", url).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @FXML
    void goYoutube() {
        try {

            new ProcessBuilder("https://www.youtube.com/channel/UCUfyDtSc_D8cwelr_s5OVbA", url).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void goLinkedIn() {
        try {

            new ProcessBuilder("https://www.linkedin.com/in/ivy-echem-6649739a", url).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @FXML
    void goTwitter() {
        try {

            new ProcessBuilder("https://twitter.com/Vykore", url).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void goInstagram() {
        try {

            new ProcessBuilder("https://github.com/Vyxact", url).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
